# ABYSSPANEL

لوحة تحكم متكاملة لإدارة التطبيقات في Termux/Proot/Linux.

## التثبيت
```bash
git clone https://github.com/username/abysspanel.git
cd abysspanel
chmod +x install.sh
./install.sh