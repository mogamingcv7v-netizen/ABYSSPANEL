import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///data/abysspanel.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'
    PORT = int(os.environ.get('PORT', 5000))
    DOMAIN = os.environ.get('DOMAIN', '')
    
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    DATA_DIR = os.path.join(BASE_DIR, 'data')
    APPS_DIR = os.path.join(DATA_DIR, 'apps')
    BACKUPS_DIR = os.path.join(DATA_DIR, 'backups')
    LOGS_DIR = os.path.join(DATA_DIR, 'logs')
    
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB
    SESSION_COOKIE_SECURE = False
    REMEMBER_COOKIE_SECURE = False