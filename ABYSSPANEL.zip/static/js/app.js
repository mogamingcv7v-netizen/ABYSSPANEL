// ABYSSPANEL JavaScript

// اتصال WebSocket (إذا كان متاحًا)
let socket = null;
try {
    socket = io();
    console.log('WebSocket connected');
} catch(e) {
    console.log('WebSocket not available');
}

// تحديث الموارد في الوقت الفعلي
if (socket) {
    socket.on('resources', function(data) {
        if (window.location.pathname === '/resources') {
            updateResourceDisplay(data);
        }
    });
}

function updateResourceDisplay(data) {
    const cpuElement = document.getElementById('cpu');
    const cpuBar = document.querySelector('.progress-bar-cpu');
    if (cpuElement) cpuElement.innerText = data.cpu;
    if (cpuBar) cpuBar.style.width = data.cpu + '%';
    
    const memoryElement = document.getElementById('memory');
    const memoryBar = document.querySelector('.progress-bar-memory');
    if (memoryElement) memoryElement.innerText = data.memory;
    if (memoryBar) memoryBar.style.width = data.memory + '%';
}

// تأكيد الحذف
function confirmDelete(message) {
    return confirm(message || '⚠️ هل أنت متأكد من الحذف؟ هذا الإجراء لا يمكن التراجع عنه.');
}

// عرض رسالة منبثقة
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 end-0 m-3`;
    toast.style.zIndex = '9999';
    toast.style.minWidth = '250px';
    toast.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// نسخ النص إلى الحافظة
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast('📋 تم النسخ!', 'success');
    }).catch(() => {
        showToast('❌ فشل النسخ', 'error');
    });
}

// تحديث حالة التطبيقات تلقائيًا
function refreshAppStatus() {
    document.querySelectorAll('[data-app-id]').forEach(el => {
        const appId = el.dataset.appId;
        fetch(`/api/v1/apps/${appId}/status`)
            .then(res => res.json())
            .then(data => {
                const statusSpan = document.querySelector(`#app-status-${appId}`);
                if (statusSpan) {
                    statusSpan.innerText = data.status === 'running' ? 'يعمل' : 'متوقف';
                    statusSpan.className = `status-${data.status}`;
                }
            });
    });
}

// تشغيل التحديث التلقائي كل 5 ثوانٍ
if (document.querySelector('[data-app-id]')) {
    setInterval(refreshAppStatus, 5000);
}

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    // إضافة تأكيد للحذف لجميع النماذج
    document.querySelectorAll('form[action*="delete"]').forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!confirm('⚠️ هل أنت متأكد من الحذف؟')) {
                e.preventDefault();
            }
        });
    });
    
    // إضافة تأثير hover للجداول
    document.querySelectorAll('.table').forEach(table => {
        table.classList.add('table-hover');
    });
    
    console.log('ABYSSPANEL loaded successfully');
});