#!/bin/bash

###############################################################################
# ABYSSPANEL - Complete Installer
# A comprehensive panel for managing applications in Termux/Proot/Linux
###############################################################################

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'
MAGENTA='\033[0;35m'; CYAN='\033[0;36m'; WHITE='\033[1;37m'; BOLD='\033[1m'; NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$SCRIPT_DIR"
DATA_DIR="$INSTALL_DIR/data"
VENV_DIR="$INSTALL_DIR/venv"
SUPERVISOR_CONF_DIR="$HOME/.supervisor"
SUPERVISOR_CONF="$SUPERVISOR_CONF_DIR/supervisord.conf"
ABYSSPANEL_CONF="$SUPERVISOR_CONF_DIR/conf.d/abysspanel.conf"

PORT=5000
DOMAIN=""
ADMIN_USER="admin"
ADMIN_PASS=""
CREATE_ADMIN=true
USE_VENV=true
USE_SUPERVISOR=true
AUTO_START=true
DEBUG_MODE=false
INSTALL_NODE=false
INSTALL_PHP=false
BACKUP_EXISTING=true
ENV="unknown"

print_header() {
    echo -e "\n${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║${NC}${BOLD}${WHITE}                    ABYSSPANEL INSTALLER                      ${NC}${CYAN}║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}\n"
}
print_step() { echo -e "${BLUE}┌─────────────────────────────────────────────────────────┐${NC}\n${BLUE}│ ${BOLD}➜ $1${NC}\n${BLUE}└─────────────────────────────────────────────────────────┘${NC}\n"; }
print_success() { echo -e "${GREEN}✅ $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_info() { echo -e "${MAGENTA}ℹ️  $1${NC}"; }
print_progress() { echo -e "${CYAN}⏳ $1${NC}"; }

confirm() {
    local default="${2:-n}"
    local prompt="$1"
    if [[ "$default" == "y" ]]; then prompt="$prompt [Y/n]: "; else prompt="$prompt [y/N]: "; fi
    read -p "$(echo -e "${YELLOW}❓ ${prompt}${NC}")" response
    case "$response" in [yY][eE][sS]|[yY]) return 0;; *) return $([[ "$default" == "y" ]] && echo 0 || echo 1);; esac
}
command_exists() { command -v "$1" >/dev/null 2>&1; }
get_random_password() { if command_exists openssl; then openssl rand -base64 12 | tr -d '/+=' | cut -c1-16; else echo "ABYSSPASS$(date +%s | sha256sum | base64 | head -c 8)"; fi; }

detect_environment() {
    print_step "Detecting environment..."
    if command_exists termux-setup-storage; then ENV="termux"; print_info "✅ Termux detected"; else ENV="linux"; print_info "✅ Linux system detected"; fi
    if command_exists python3; then PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2); print_info "🐍 Python $PYTHON_VERSION found"; else print_warning "Python not found, will install"; fi
    if command_exists pip3 || command_exists pip; then print_info "📦 pip found"; else print_warning "pip not found, will install"; fi
}

install_base_packages() {
    print_step "Installing base packages..."
    case "$ENV" in
        termux)
            print_progress "Updating Termux..."; pkg update -y 2>/dev/null || true; pkg upgrade -y 2>/dev/null || true
            print_progress "Installing Python and pip..."; pkg install -y python python-pip git openssl-tool curl wget 2>/dev/null || true ;;
        linux)
            print_progress "Installing packages..."
            if command_exists apt; then sudo apt update -y 2>/dev/null || true; sudo apt install -y python3 python3-pip git curl wget openssl 2>/dev/null || true
            elif command_exists yum; then sudo yum install -y python3 python3-pip git curl wget openssl 2>/dev/null || true
            elif command_exists pacman; then sudo pacman -S --noconfirm python python-pip git curl wget openssl 2>/dev/null || true
            else print_warning "Package manager not recognized, please install Python and pip manually"; fi ;;
    esac
    if ! command_exists pip3 && ! command_exists pip; then print_progress "Installing pip via get-pip.py..."; curl -sS https://bootstrap.pypa.io/get-pip.py | python3; fi
    print_success "Base packages installed"
}

install_nodejs() {
    if $INSTALL_NODE; then
        print_step "Installing Node.js..."
        case "$ENV" in termux) pkg install -y nodejs 2>/dev/null || true ;;
            linux) if command_exists apt; then curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -; sudo apt install -y nodejs; else print_warning "Automatic Node.js installation not supported"; fi ;;
        esac
        print_success "Node.js installed: $(node -v 2>/dev/null || echo 'not available')"
    fi
}

install_php() {
    if $INSTALL_PHP; then
        print_step "Installing PHP..."
        case "$ENV" in termux) pkg install -y php 2>/dev/null || true ;;
            linux) if command_exists apt; then sudo apt install -y php php-cli 2>/dev/null || true; else print_warning "Automatic PHP installation not supported"; fi ;;
        esac
        print_success "PHP installed: $(php -v 2>/dev/null | head -1 || echo 'not available')"
    fi
}

setup_venv() {
    if $USE_VENV; then
        print_step "Setting up virtual environment..."
        if [ -d "$VENV_DIR" ] && $BACKUP_EXISTING; then print_info "Existing venv found, backing up..."; mv "$VENV_DIR" "$VENV_DIR.bak.$(date +%s)" 2>/dev/null || true; fi
        python3 -m venv "$VENV_DIR"
        source "$VENV_DIR/bin/activate"
        print_success "Virtual environment created and activated"
    else print_info "Will use system Python"; fi
}

install_python_requirements() {
    print_step "Installing Python requirements..."
    if $USE_VENV; then PIP_CMD="$VENV_DIR/bin/pip"; else PIP_CMD="pip3"; if ! command_exists pip3; then PIP_CMD="pip"; fi; fi
    $PIP_CMD install --upgrade pip setuptools wheel
    if [ -f "$INSTALL_DIR/requirements.txt" ]; then $PIP_CMD install -r "$INSTALL_DIR/requirements.txt"; else print_error "requirements.txt not found!"; exit 1; fi
    print_success "All requirements installed"
}

setup_config() {
    print_step "Setting up configuration files..."
    mkdir -p "$DATA_DIR/apps" "$DATA_DIR/backups" "$DATA_DIR/logs"
    cat > "$INSTALL_DIR/.env" << EOF
# ABYSSPANEL Configuration
SECRET_KEY=$(get_random_password)$(date +%s | sha256sum | head -c 32)
PORT=$PORT
DOMAIN=$DOMAIN
DEBUG=$DEBUG_MODE
EOF
    print_success "Configuration files created"
}

setup_database() {
    print_step "Setting up database and admin user..."
    cat > "$INSTALL_DIR/setup_db.py" << EOF
import sys, os
sys.path.insert(0, '$INSTALL_DIR')
os.chdir('$INSTALL_DIR')
from app import create_app, db
from app.models import User
app = create_app()
with app.app_context():
    db.create_all()
    print("✅ Database created")
    if $CREATE_ADMIN:
        admin_user = User.query.filter_by(username='$ADMIN_USER').first()
        if not admin_user:
            admin = User(username='$ADMIN_USER', email='admin@localhost', is_admin=True)
            admin.set_password('$ADMIN_PASS')
            db.session.add(admin)
            db.session.commit()
            print(f"✅ Admin user created: $ADMIN_USER / $ADMIN_PASS")
        else:
            print("ℹ️ Admin user already exists")
EOF
    if $USE_VENV; then "$VENV_DIR/bin/python" "$INSTALL_DIR/setup_db.py"; else python3 "$INSTALL_DIR/setup_db.py"; fi
    rm -f "$INSTALL_DIR/setup_db.py"
    print_success "Database ready"
}

setup_supervisor() {
    if ! $USE_SUPERVISOR; then print_info "Skipping Supervisor setup"; return 0; fi
    print_step "Setting up Supervisor..."
    if ! command_exists supervisord; then
        print_progress "Installing Supervisor..."
        if $USE_VENV; then "$VENV_DIR/bin/pip" install supervisor; SUPERVISOR_CMD="$VENV_DIR/bin/supervisord"; SUPERVISORCTL_CMD="$VENV_DIR/bin/supervisorctl"
        else pip3 install supervisor; SUPERVISOR_CMD="supervisord"; SUPERVISORCTL_CMD="supervisorctl"; fi
        print_success "Supervisor installed"
    else SUPERVISOR_CMD="supervisord"; SUPERVISORCTL_CMD="supervisorctl"; fi
    mkdir -p "$SUPERVISOR_CONF_DIR/conf.d"
    cat > "$SUPERVISOR_CONF" << 'EOF'
[unix_http_server]
file=/tmp/supervisor.sock
chmod=0700
[supervisord]
logfile=~/.supervisor/supervisord.log
logfile_maxbytes=50MB
logfile_backups=10
loglevel=info
pidfile=/tmp/supervisord.pid
nodaemon=false
minfds=1024
minprocs=200
[rpcinterface:supervisor]
supervisor.rpcinterface_factory = supervisor.rpcinterface:make_main_rpcinterface
[supervisorctl]
serverurl=unix:///tmp/supervisor.sock
[include]
files = ~/.supervisor/conf.d/*.conf
EOF
    cat > "$ABYSSPANEL_CONF" << EOF
[program:abysspanel]
command=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/run.py
directory=$INSTALL_DIR
user=$(whoami)
autostart=true
autorestart=true
startsecs=10
stopasgroup=true
killasgroup=true
redirect_stderr=true
stdout_logfile=$DATA_DIR/logs/abysspanel.log
stdout_logfile_maxbytes=50MB
stdout_logfile_backups=10
environment=PATH="$INSTALL_DIR/venv/bin:/usr/local/bin:/usr/bin:/bin"
EOF
    print_success "Supervisor configuration ready"
}

setup_auto_start() {
    if ! $AUTO_START; then print_info "Skipping auto-start setup"; return 0; fi
    print_step "Setting up auto-start..."
    case "$ENV" in
        termux)
            mkdir -p ~/.termux/boot
            cat > ~/.termux/boot/abysspanel.sh << EOF
#!/data/data/com.termux/files/usr/bin/bash
# ABYSSPANEL auto-start
sleep 5
$SUPERVISOR_CMD -c $SUPERVISOR_CONF 2>/dev/null &
EOF
            chmod +x ~/.termux/boot/abysspanel.sh
            print_success "Auto-start configured for Termux" ;;
        linux)
            if command_exists systemctl && [ -d /etc/systemd/system ]; then
                sudo tee /etc/systemd/system/abysspanel.service > /dev/null << EOF
[Unit]
Description=ABYSSPANEL Panel
After=network.target
[Service]
Type=simple
User=$(whoami)
WorkingDirectory=$INSTALL_DIR
ExecStart=$SUPERVISOR_CMD -c $SUPERVISOR_CONF
Restart=on-failure
RestartSec=10
[Install]
WantedBy=multi-user.target
EOF
                sudo systemctl daemon-reload; sudo systemctl enable abysspanel.service
                print_success "systemd service configured"
            else
                (crontab -l 2>/dev/null; echo "@reboot $SUPERVISOR_CMD -c $SUPERVISOR_CONF") | crontab -
                print_success "Added to crontab"
            fi ;;
    esac
}

create_control_scripts() {
    print_step "Creating control scripts..."
    cat > "$INSTALL_DIR/start.sh" << EOF
#!/bin/bash
cd "$INSTALL_DIR"
if [ -f "$VENV_DIR/bin/activate" ]; then source "$VENV_DIR/bin/activate"; fi
python run.py
EOF
    chmod +x "$INSTALL_DIR/start.sh"
    cat > "$INSTALL_DIR/abysspanel-ctl" << EOF
#!/bin/bash
SUPERVISOR_CMD="$SUPERVISORCTL_CMD"
SUPERVISOR_CONF="$SUPERVISOR_CONF"
case "\$1" in
    start) \$SUPERVISOR_CMD -c "\$SUPERVISOR_CONF" start abysspanel ;;
    stop) \$SUPERVISOR_CMD -c "\$SUPERVISOR_CONF" stop abysspanel ;;
    restart) \$SUPERVISOR_CMD -c "\$SUPERVISOR_CONF" restart abysspanel ;;
    status) \$SUPERVISOR_CMD -c "\$SUPERVISOR_CONF" status abysspanel ;;
    logs) \$SUPERVISOR_CMD -c "\$SUPERVISOR_CONF" tail -f abysspanel ;;
    supervisor-start) $SUPERVISOR_CMD -c "\$SUPERVISOR_CONF" ;;
    supervisor-stop) \$SUPERVISOR_CMD -c "\$SUPERVISOR_CONF" shutdown ;;
    *) echo "Usage: \$0 {start|stop|restart|status|logs|supervisor-start|supervisor-stop}"; exit 1 ;;
esac
EOF
    chmod +x "$INSTALL_DIR/abysspanel-ctl"
    print_success "Control scripts created"
}

start_services() {
    if $USE_SUPERVISOR && $AUTO_START; then
        print_step "Starting services..."
        $SUPERVISORCTL_CMD -c "$SUPERVISOR_CONF" shutdown 2>/dev/null || true; sleep 2
        $SUPERVISOR_CMD -c "$SUPERVISOR_CONF"; sleep 3
        $SUPERVISORCTL_CMD -c "$SUPERVISOR_CONF" start abysspanel 2>/dev/null || true
        print_success "Services started"
    fi
}

show_completion() {
    print_header
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              ✅ ABYSSPANEL installed successfully!        ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}\n"
    echo -e "${WHITE}📁 Installation info:${NC}"
    echo -e "   ├─ Install path: ${CYAN}$INSTALL_DIR${NC}"
    echo -e "   ├─ Data: ${CYAN}$DATA_DIR${NC}"
    if $USE_VENV; then echo -e "   ├─ Virtual environment: ${CYAN}$VENV_DIR${NC}"; fi
    echo -e "   ├─ Port: ${CYAN}$PORT${NC}"
    if [ -n "$DOMAIN" ]; then echo -e "   └─ Domain: ${CYAN}$DOMAIN${NC}"; fi
    if $CREATE_ADMIN; then
        echo -e "\n${WHITE}👤 Login details:${NC}"
        echo -e "   ├─ Username: ${CYAN}$ADMIN_USER${NC}"
        echo -e "   └─ Password: ${CYAN}$ADMIN_PASS${NC}"
        echo -e "\n${YELLOW}⚠️  Please change the password after first login!${NC}"
    fi
    echo -e "\n${WHITE}🚀 How to run:${NC}"
    if $USE_SUPERVISOR && $AUTO_START; then
        echo -e "   ├─ Services are running in background"
        echo -e "   ├─ Check status: ${CYAN}./abysspanel-ctl status${NC}"
        echo -e "   ├─ View logs: ${CYAN}./abysspanel-ctl logs${NC}"
        echo -e "   └─ Stop service: ${CYAN}./abysspanel-ctl stop${NC}"
    else echo -e "   └─ Manual start: ${CYAN}./start.sh${NC}"; fi
    echo -e "\n${WHITE}🌐 Open panel:${NC}"
    echo -e "   └─ ${CYAN}http://localhost:$PORT${NC}"
    echo -e "\n${GREEN}✨ Enjoy using ABYSSPANEL! ✨${NC}\n"
}

advanced_config() {
    echo -e "\n${CYAN}⚙️  Advanced Settings${NC}\n${YELLOW}─────────────────────────────────────────────────────────${NC}\n"
    read -p "🔌 Port [$PORT]: " input; PORT=${input:-$PORT}
    read -p "🌐 Domain (leave empty for local): " DOMAIN
    echo ""
    confirm "🔧 Use virtual environment (venv)?" && USE_VENV=true || USE_VENV=false
    confirm "📦 Use Supervisor for process management?" && USE_SUPERVISOR=true || USE_SUPERVISOR=false
    confirm "⚡ Auto-start on boot?" && AUTO_START=true || AUTO_START=false
    confirm "🐞 Enable DEBUG mode?" && DEBUG_MODE=true || DEBUG_MODE=false
    echo ""
    confirm "👤 Create admin user?" && CREATE_ADMIN=true || CREATE_ADMIN=false
    if $CREATE_ADMIN; then
        read -p "   Username [$ADMIN_USER]: " input; ADMIN_USER=${input:-$ADMIN_USER}
        read -s -p "   Password (leave empty to generate): " ADMIN_PASS; echo ""
        if [ -z "$ADMIN_PASS" ]; then ADMIN_PASS=$(get_random_password); print_info "Auto-generated password: $ADMIN_PASS"; fi
    fi
    echo ""
    confirm "🟢 Install Node.js?" && INSTALL_NODE=true || INSTALL_NODE=false
    confirm "🐘 Install PHP?" && INSTALL_PHP=true || INSTALL_PHP=false
    confirm "💾 Backup existing files?" && BACKUP_EXISTING=true || BACKUP_EXISTING=false
}

main() {
    clear; print_header
    echo -e "${WHITE}This installer will fully set up ABYSSPANEL on your system.${NC}"
    echo -e "${WHITE}It will handle all requirements: Python, pip, Supervisor, etc.${NC}\n"
    if confirm "Do you want to use advanced settings?" "n"; then advanced_config
    else
        read -p "🔌 Port [$PORT]: " input; PORT=${input:-$PORT}
        echo ""
        confirm "👤 Create admin user?" && CREATE_ADMIN=true || CREATE_ADMIN=false
        if $CREATE_ADMIN; then
            read -p "   Username [$ADMIN_USER]: " input; ADMIN_USER=${input:-$ADMIN_USER}
            read -s -p "   Password (leave empty to generate): " ADMIN_PASS; echo ""
            if [ -z "$ADMIN_PASS" ]; then ADMIN_PASS=$(get_random_password); print_info "Auto-generated password: $ADMIN_PASS"; fi
        fi
    fi
    detect_environment
    install_base_packages
    install_nodejs
    install_php
    setup_venv
    install_python_requirements
    setup_config
    setup_database
    setup_supervisor
    setup_auto_start
    create_control_scripts
    start_services
    show_completion
}

main "$@"