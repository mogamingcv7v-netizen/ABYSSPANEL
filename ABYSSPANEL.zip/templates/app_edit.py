{% extends "base.html" %}
{% block title %}{{ 'تعديل تطبيق' if app else 'إضافة تطبيق' }}{% endblock %}
{% block content %}
<div class="card p-4">
    <h1>{{ 'تعديل تطبيق' if app else 'إضافة تطبيق جديد' }}</h1>
    <form method="post">
        {{ form.hidden_tag() }}
        
        <div class="mb-3">
            {{ form.name.label(class="form-label") }}
            {{ form.name(class="form-control") }}
            <small class="text-muted">اسم التطبيق الذي سيظهر في اللوحة</small>
        </div>
        
        <div class="mb-3">
            {{ form.type.label(class="form-label") }}
            {{ form.type(class="form-select") }}
            <small class="text-muted">نوع التطبيق لتحديد الإعدادات المناسبة</small>
        </div>
        
        <div class="mb-3">
            {{ form.command.label(class="form-label") }}
            {{ form.command(class="form-control", rows=5) }}
            <small class="text-muted">
                الأمر الكامل لتشغيل التطبيق. أمثلة:<br>
                • Node.js: <code>node index.js</code><br>
                • Python: <code>python app.py</code><br>
                • Bash: <code>./start.sh</code><br>
                • PHP: <code>php -S 0.0.0.0:8080</code>
            </small>
        </div>
        
        <div class="mb-3">
            {{ form.workdir.label(class="form-label") }}
            {{ form.workdir(class="form-control") }}
            <small class="text-muted">
                اتركه فارغًا لإنشاء مجلد افتراضي داخل <code>data/apps/</code><br>
                أو أدخل مسارًا مطلقًا (مثل <code>/data/data/com.termux/files/home/myapp</code>)
            </small>
        </div>
        
        <div class="mb-3">
            {{ form.env_vars.label(class="form-label") }}
            {{ form.env_vars(class="form-control", rows=3) }}
            <small class="text-muted">
                متغيرات البيئة بصيغة JSON. مثال:<br>
                <code>{"PORT": "3000", "NODE_ENV": "production"}</code>
            </small>
        </div>
        
        <div class="d-flex gap-2">
            {{ form.submit(class="btn btn-primary") }}
            <a href="{{ url_for('apps.list_apps') }}" class="btn btn-secondary">إلغاء</a>
        </div>
    </form>
</div>
{% endblock %}