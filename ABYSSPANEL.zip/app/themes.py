import os
import json
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required

THEMES_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'theme.json')

# 40 ثيمًا كاملًا
THEMES = [
    {"name": "GitHub Dark", "bg": "#0d1117", "card": "#161b22", "text": "#c9d1d9", "primary": "#238636", "accent": "#58a6ff"},
    {"name": "Dracula", "bg": "#282a36", "card": "#44475a", "text": "#f8f8f2", "primary": "#bd93f9", "accent": "#ff79c6"},
    {"name": "Nord", "bg": "#2e3440", "card": "#3b4252", "text": "#d8dee9", "primary": "#88c0d0", "accent": "#5e81ac"},
    {"name": "One Dark", "bg": "#282c34", "card": "#353b45", "text": "#abb2bf", "primary": "#61afef", "accent": "#c678dd"},
    {"name": "Solarized Dark", "bg": "#002b36", "card": "#073642", "text": "#839496", "primary": "#268bd2", "accent": "#2aa198"},
    {"name": "Gruvbox Dark", "bg": "#282828", "card": "#3c3836", "text": "#ebdbb2", "primary": "#fe8019", "accent": "#8ec07c"},
    {"name": "Monokai", "bg": "#272822", "card": "#3e3d32", "text": "#f8f8f2", "primary": "#f92672", "accent": "#a6e22e"},
    {"name": "Material Dark", "bg": "#263238", "card": "#37474f", "text": "#eceff1", "primary": "#009688", "accent": "#ff5722"},
    {"name": "Tokyo Night", "bg": "#1a1b26", "card": "#24283b", "text": "#c0caf5", "primary": "#7aa2f7", "accent": "#bb9af7"},
    {"name": "Catppuccin Mocha", "bg": "#1e1e2e", "card": "#302d41", "text": "#cdd6f4", "primary": "#89b4fa", "accent": "#f38ba8"},
    {"name": "Everforest Dark", "bg": "#2b3339", "card": "#3c4a4f", "text": "#d3c6aa", "primary": "#a7c080", "accent": "#e67e80"},
    {"name": "Kanagawa", "bg": "#1f1f28", "card": "#2a2a37", "text": "#dcd7ba", "primary": "#7fb4ca", "accent": "#e46876"},
    {"name": "Rosé Pine", "bg": "#191724", "card": "#1f1d2e", "text": "#e0def4", "primary": "#31748f", "accent": "#eb6f92"},
    {"name": "Moonfly", "bg": "#080808", "card": "#121212", "text": "#cdcdcd", "primary": "#8cc84c", "accent": "#e95678"},
    {"name": "Night Owl", "bg": "#011627", "card": "#011627", "text": "#d6deeb", "primary": "#82aaff", "accent": "#c792ea"},
    {"name": "Ayu Dark", "bg": "#0f1419", "card": "#1a1f26", "text": "#e6e1cf", "primary": "#ffb454", "accent": "#f07178"},
    {"name": "Space Gray", "bg": "#1e1e1e", "card": "#2c2c2c", "text": "#e0e0e0", "primary": "#007acc", "accent": "#9cdcfe"},
    {"name": "Solarized Light", "bg": "#fdf6e3", "card": "#eee8d5", "text": "#657b83", "primary": "#268bd2", "accent": "#2aa198"},
    {"name": "GitHub Light", "bg": "#ffffff", "card": "#f6f8fa", "text": "#24292f", "primary": "#2da44e", "accent": "#0969da"},
    {"name": "Gruvbox Light", "bg": "#fbf1c7", "card": "#ebdbb2", "text": "#3c3836", "primary": "#cc241d", "accent": "#458588"},
    {"name": "Catppuccin Latte", "bg": "#eff1f5", "card": "#e6e9ef", "text": "#4c4f69", "primary": "#1e66f5", "accent": "#ea76cb"},
    {"name": "Tokyo Night Storm", "bg": "#24283b", "card": "#2a2f44", "text": "#c0caf5", "primary": "#7aa2f7", "accent": "#bb9af7"},
    {"name": "Nord Light", "bg": "#eceff4", "card": "#e5e9f0", "text": "#2e3440", "primary": "#5e81ac", "accent": "#88c0d0"},
    {"name": "PaperColor", "bg": "#eeeeee", "card": "#ffffff", "text": "#444444", "primary": "#0087af", "accent": "#af5f00"},
    {"name": "Breeze Dark", "bg": "#232629", "card": "#31363b", "text": "#eff0f1", "primary": "#3daee9", "accent": "#f67400"},
    {"name": "Adwaita", "bg": "#2e3436", "card": "#3b4144", "text": "#eeeeec", "primary": "#729fcf", "accent": "#f57900"},
    {"name": "High Contrast", "bg": "#000000", "card": "#1e1e1e", "text": "#ffffff", "primary": "#ffff00", "accent": "#00ff00"},
    {"name": "Horizon Dark", "bg": "#1c1e26", "card": "#232530", "text": "#e0e0e0", "primary": "#e95678", "accent": "#fab387"},
    {"name": "Synthwave 84", "bg": "#241b2f", "card": "#2a213a", "text": "#f8f8f2", "primary": "#f97e72", "accent": "#72f1b8"},
    {"name": "Palenight", "bg": "#292d3e", "card": "#2e334b", "text": "#a6accd", "primary": "#82aaff", "accent": "#c792ea"},
    {"name": "Cobalt2", "bg": "#132738", "card": "#193549", "text": "#e1e1e1", "primary": "#ffc600", "accent": "#ff628c"},
    {"name": "Noctis", "bg": "#1b2b34", "card": "#2c3e50", "text": "#cdd3de", "primary": "#99c794", "accent": "#fac863"},
    {"name": "Outrun", "bg": "#00002c", "card": "#0a0f2a", "text": "#ffffff", "primary": "#ff00ff", "accent": "#00ffff"},
    {"name": "Blueberry", "bg": "#0f172a", "card": "#1e293b", "text": "#cbd5e1", "primary": "#3b82f6", "accent": "#8b5cf6"},
    {"name": "Forest", "bg": "#0a2f1f", "card": "#1a3a2a", "text": "#c0e0c0", "primary": "#6b8c42", "accent": "#c5a35b"},
    {"name": "Sunset", "bg": "#2c1a2e", "card": "#3a2a3a", "text": "#f0d0c0", "primary": "#d68c5c", "accent": "#e6b86e"},
    {"name": "Aqua", "bg": "#004d4d", "card": "#006666", "text": "#e0f0f0", "primary": "#80ff80", "accent": "#ffff80"},
    {"name": "Grayscale", "bg": "#2c2c2c", "card": "#3c3c3c", "text": "#f0f0f0", "primary": "#8c8c8c", "accent": "#cccccc"},
    {"name": "Red Alert", "bg": "#2a0f0f", "card": "#3a1a1a", "text": "#ffc0c0", "primary": "#ff4444", "accent": "#ff8888"},
    {"name": "Green Tea", "bg": "#1f2a1f", "card": "#2e3a2e", "text": "#c0e0c0", "primary": "#88cc88", "accent": "#aaffaa"},
]

def get_current_theme():
    if os.path.exists(THEMES_FILE):
        with open(THEMES_FILE, 'r') as f:
            return json.load(f)
    return THEMES[0]

def save_theme(theme):
    os.makedirs(os.path.dirname(THEMES_FILE), exist_ok=True)
    with open(THEMES_FILE, 'w') as f:
        json.dump(theme, f, indent=4)

bp = Blueprint('themes', __name__)

@bp.route('/', methods=['GET', 'POST'])
@login_required
def themes():
    if request.method == 'POST':
        theme_idx = int(request.form.get('theme_idx', 0))
        if 0 <= theme_idx < len(THEMES):
            save_theme(THEMES[theme_idx])
            flash('تم تغيير الثيم', 'success')
        return redirect(url_for('index'))
    return render_template('themes.html', themes=THEMES, current_theme=get_current_theme())