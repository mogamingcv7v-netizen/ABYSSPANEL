import os
import tarfile
import shutil
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request, send_file, current_app
from flask_login import login_required
from app import db
from app.models import Backup, App

bp = Blueprint('backups', __name__)

def create_backup(name, app_id=None):
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_name = f"{name}_{timestamp}.tar.gz"
    backup_path = os.path.join(current_app.config['BACKUPS_DIR'], backup_name)
    os.makedirs(current_app.config['BACKUPS_DIR'], exist_ok=True)
    
    if app_id:
        app = App.query.get(app_id)
        if app and os.path.exists(app.workdir):
            with tarfile.open(backup_path, 'w:gz') as tar:
                tar.add(app.workdir, arcname=os.path.basename(app.workdir))
            size = os.path.getsize(backup_path)
            backup = Backup(
                name=backup_name,
                path=backup_path,
                size=size,
                created_at=datetime.utcnow()
            )
            db.session.add(backup)
            db.session.commit()
            return backup
    else:
        # نسخة احتياطية كاملة للمشروع
        with tarfile.open(backup_path, 'w:gz') as tar:
            tar.add(current_app.config['DATA_DIR'], arcname='data')
            tar.add(current_app.config['APPS_DIR'], arcname='apps')
        size = os.path.getsize(backup_path)
        backup = Backup(
            name=backup_name,
            path=backup_path,
            size=size,
            created_at=datetime.utcnow()
        )
        db.session.add(backup)
        db.session.commit()
        return backup
    return None

def list_backups():
    return Backup.query.order_by(Backup.created_at.desc()).all()

def restore_backup(backup_id):
    backup = Backup.query.get(backup_id)
    if backup and os.path.exists(backup.path):
        import tempfile
        temp_dir = tempfile.mkdtemp()
        with tarfile.open(backup.path, 'r:gz') as tar:
            tar.extractall(temp_dir)
        return temp_dir
    return None

@bp.route('/')
@login_required
def list_backups_route():
    backups = list_backups()
    apps = App.query.all()
    return render_template('backups.html', backups=backups, apps=apps)

@bp.route('/create', methods=['POST'])
@login_required
def create_backup_route():
    name = request.form.get('name')
    app_id = request.form.get('app_id')
    if name:
        create_backup(name, int(app_id) if app_id and app_id != '' else None)
        flash('تم إنشاء النسخة الاحتياطية', 'success')
    else:
        flash('يرجى إدخال اسم للنسخة', 'danger')
    return redirect(url_for('backups.list_backups_route'))

@bp.route('/<int:backup_id>/download')
@login_required
def download_backup(backup_id):
    backup = Backup.query.get(backup_id)
    if backup and os.path.exists(backup.path):
        return send_file(
            backup.path,
            as_attachment=True,
            download_name=backup.name
        )
    flash('الملف غير موجود', 'danger')
    return redirect(url_for('backups.list_backups_route'))

@bp.route('/<int:backup_id>/delete', methods=['POST'])
@login_required
def delete_backup(backup_id):
    backup = Backup.query.get(backup_id)
    if backup:
        if os.path.exists(backup.path):
            os.remove(backup.path)
        db.session.delete(backup)
        db.session.commit()
        flash('تم حذف النسخة', 'success')
    return redirect(url_for('backups.list_backups_route'))

@bp.route('/<int:backup_id>/restore', methods=['POST'])
@login_required
def restore_backup_route(backup_id):
    backup = Backup.query.get(backup_id)
    if backup:
        restore_dir = restore_backup(backup_id)
        if restore_dir:
            flash('تم استعادة النسخة الاحتياطية (تم الاستخراج إلى مجلد مؤقت)', 'success')
        else:
            flash('فشل استعادة النسخة', 'danger')
    return redirect(url_for('backups.list_backups_route'))