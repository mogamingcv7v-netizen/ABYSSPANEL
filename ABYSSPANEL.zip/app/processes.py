import os
import signal
import subprocess
import json
from flask import Blueprint, redirect, url_for, flash, request, current_app
from flask_login import login_required

PID_FILE = os.path.join(current_app.config['DATA_DIR'], 'pids.json')

def load_pids():
    if os.path.exists(PID_FILE):
        with open(PID_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_pids(pids):
    os.makedirs(os.path.dirname(PID_FILE), exist_ok=True)
    with open(PID_FILE, 'w') as f:
        json.dump(pids, f, indent=4)

def is_process_running(pid):
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def start_app(app_id):
    from app.models import App
    app = App.query.get(app_id)
    if not app:
        return False
    
    pids = load_pids()
    if str(app_id) in pids and is_process_running(pids[str(app_id)]):
        return False
    
    script_path = os.path.join(app.workdir, 'run.sh')
    if not os.path.exists(script_path):
        with open(script_path, 'w') as f:
            f.write(f'#!/bin/sh\ncd "{app.workdir}"\n{app.command}\n')
        os.chmod(script_path, 0o755)
    
    # تشغيل العملية
    proc = subprocess.Popen(
        ['sh', script_path],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        cwd=app.workdir
    )
    pids[str(app_id)] = proc.pid
    save_pids(pids)
    return True

def stop_app(app_id):
    pids = load_pids()
    if str(app_id) in pids:
        pid = pids[str(app_id)]
        try:
            os.kill(pid, signal.SIGTERM)
            import time
            time.sleep(2)
            if is_process_running(pid):
                os.kill(pid, signal.SIGKILL)
        except:
            pass
        del pids[str(app_id)]
        save_pids(pids)
        return True
    return False

def restart_app(app_id):
    stop_app(app_id)
    import time
    time.sleep(1)
    start_app(app_id)

def get_app_status(app_id):
    pids = load_pids()
    if str(app_id) in pids and is_process_running(pids[str(app_id)]):
        return 'running'
    return 'stopped'

bp = Blueprint('processes', __name__)

@bp.route('/<int:app_id>/start', methods=['POST'])
@login_required
def start(app_id):
    start_app(app_id)
    flash('تم تشغيل التطبيق', 'success')
    return redirect(request.referrer or url_for('index'))

@bp.route('/<int:app_id>/stop', methods=['POST'])
@login_required
def stop(app_id):
    stop_app(app_id)
    flash('تم إيقاف التطبيق', 'success')
    return redirect(request.referrer or url_for('index'))

@bp.route('/<int:app_id>/restart', methods=['POST'])
@login_required
def restart(app_id):
    restart_app(app_id)
    flash('تم إعادة تشغيل التطبيق', 'success')
    return redirect(request.referrer or url_for('index'))