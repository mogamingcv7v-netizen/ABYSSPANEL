from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from app.models import App, User, CronJob, Backup
from app.processes import start_app, stop_app, restart_app, get_app_status
from app.apps import get_all_apps
import psutil

bp = Blueprint('api', __name__)

@bp.route('/apps', methods=['GET'])
@login_required
def list_apps():
    apps = get_all_apps()
    return jsonify([{
        'id': a.id,
        'name': a.name,
        'type': a.type,
        'status': get_app_status(a.id),
        'command': a.command,
        'workdir': a.workdir,
        'created_at': a.created_at.isoformat()
    } for a in apps])

@bp.route('/apps/<int:app_id>', methods=['GET'])
@login_required
def get_app(app_id):
    from app.apps import get_app as get_app_by_id
    app = get_app_by_id(app_id)
    if not app:
        return jsonify({'error': 'not found'}), 404
    return jsonify({
        'id': app.id,
        'name': app.name,
        'type': app.type,
        'status': get_app_status(app.id),
        'command': app.command,
        'workdir': app.workdir,
        'created_at': app.created_at.isoformat()
    })

@bp.route('/apps/<int:app_id>/start', methods=['POST'])
@login_required
def api_start_app(app_id):
    start_app(app_id)
    return jsonify({'status': 'started'})

@bp.route('/apps/<int:app_id>/stop', methods=['POST'])
@login_required
def api_stop_app(app_id):
    stop_app(app_id)
    return jsonify({'status': 'stopped'})

@bp.route('/apps/<int:app_id>/restart', methods=['POST'])
@login_required
def api_restart_app(app_id):
    restart_app(app_id)
    return jsonify({'status': 'restarted'})

@bp.route('/apps/<int:app_id>/status', methods=['GET'])
@login_required
def api_app_status(app_id):
    status = get_app_status(app_id)
    return jsonify({'status': status})

@bp.route('/resources', methods=['GET'])
@login_required
def api_resources():
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    return jsonify({
        'cpu': cpu,
        'memory': {
            'total': mem.total,
            'used': mem.used,
            'free': mem.free,
            'percent': mem.percent
        },
        'disk': {
            'total': disk.total,
            'used': disk.used,
            'free': disk.free,
            'percent': disk.percent
        }
    })

@bp.route('/cron', methods=['GET'])
@login_required
def list_cron():
    jobs = CronJob.query.all()
    return jsonify([{
        'id': j.id,
        'name': j.name,
        'schedule': j.schedule,
        'command': j.command,
        'enabled': j.enabled,
        'last_run': j.last_run.isoformat() if j.last_run else None
    } for j in jobs])

@bp.route('/backups', methods=['GET'])
@login_required
def list_backups():
    backups = Backup.query.all()
    return jsonify([{
        'id': b.id,
        'name': b.name,
        'size': b.size,
        'created_at': b.created_at.isoformat()
    } for b in backups])

@bp.route('/system/info', methods=['GET'])
@login_required
def system_info():
    return jsonify({
        'python_version': __import__('sys').version,
        'platform': __import__('platform').platform(),
        'hostname': __import__('socket').gethostname(),
        'user': current_user.username,
        'is_admin': current_user.is_admin
    })