import os
import shutil
import json
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required
from app import db
from app.models import App
from app.forms import AppForm
from app.processes import get_app_status

bp = Blueprint('apps', __name__)

def get_all_apps():
    return App.query.order_by(App.created_at.desc()).all()

def get_app(app_id):
    return App.query.get(app_id)

@bp.route('/')
@login_required
def list_apps():
    apps = get_all_apps()
    for app in apps:
        app.status = get_app_status(app.id)
    return render_template('apps.html', apps=apps)

@bp.route('/new', methods=['GET', 'POST'])
@login_required
def new_app():
    form = AppForm()
    if form.validate_on_submit():
        workdir = form.workdir.data.strip()
        if not workdir:
            import time
            workdir = os.path.join(current_app.config['APPS_DIR'], str(int(time.time())))
        os.makedirs(workdir, exist_ok=True)
        
        # معالجة متغيرات البيئة
        env_vars = {}
        if form.env_vars.data:
            try:
                env_vars = json.loads(form.env_vars.data)
            except:
                pass
        
        app = App(
            name=form.name.data,
            type=form.type.data,
            command=form.command.data,
            workdir=workdir,
            env_vars=json.dumps(env_vars)
        )
        db.session.add(app)
        db.session.commit()
        
        # إنشاء ملف run.sh
        script_path = os.path.join(workdir, 'run.sh')
        with open(script_path, 'w') as f:
            f.write(f'#!/bin/sh\ncd "{workdir}"\n{form.command.data}\n')
        os.chmod(script_path, 0o755)
        
        flash('تم إضافة التطبيق بنجاح', 'success')
        return redirect(url_for('apps.list_apps'))
    return render_template('app_edit.html', form=form, app=None)

@bp.route('/<int:app_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_app(app_id):
    app = get_app(app_id)
    if not app:
        flash('التطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    
    form = AppForm(obj=app)
    if form.validate_on_submit():
        app.name = form.name.data
        app.type = form.type.data
        app.command = form.command.data
        
        new_workdir = form.workdir.data.strip()
        if new_workdir and new_workdir != app.workdir:
            if os.path.exists(app.workdir):
                shutil.move(app.workdir, new_workdir)
            else:
                os.makedirs(new_workdir, exist_ok=True)
            app.workdir = new_workdir
        
        if form.env_vars.data:
            try:
                app.env_vars = json.dumps(json.loads(form.env_vars.data))
            except:
                pass
        
        db.session.commit()
        
        # تحديث ملف run.sh
        script_path = os.path.join(app.workdir, 'run.sh')
        with open(script_path, 'w') as f:
            f.write(f'#!/bin/sh\ncd "{app.workdir}"\n{app.command}\n')
        os.chmod(script_path, 0o755)
        
        flash('تم تحديث التطبيق', 'success')
        return redirect(url_for('apps.list_apps'))
    
    # تحميل متغيرات البيئة الموجودة
    try:
        form.env_vars.data = json.dumps(json.loads(app.env_vars), indent=2)
    except:
        form.env_vars.data = app.env_vars
    
    return render_template('app_edit.html', form=form, app=app)

@bp.route('/<int:app_id>/delete', methods=['POST'])
@login_required
def delete_app(app_id):
    app = get_app(app_id)
    if app:
        if os.path.exists(app.workdir):
            shutil.rmtree(app.workdir)
        db.session.delete(app)
        db.session.commit()
        flash('تم حذف التطبيق', 'success')
    return redirect(url_for('apps.list_apps'))