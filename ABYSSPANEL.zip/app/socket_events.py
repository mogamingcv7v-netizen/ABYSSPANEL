from flask_socketio import emit
from app.processes import get_app_status
import psutil
import time
import threading

def background_updater(socketio):
    while True:
        try:
            cpu = psutil.cpu_percent()
            mem = psutil.virtual_memory().percent
            socketio.emit('resources', {
                'cpu': cpu,
                'memory': mem,
                'timestamp': time.time()
            })
        except Exception as e:
            print(f"Socket error: {e}")
        time.sleep(5)

def register_socket_events(socketio):
    @socketio.on('connect')
    def handle_connect():
        print('Client connected to ABYSSPANEL')
        # بدء تحديث الخلفية إذا لم يكن قيد التشغيل
        if not hasattr(socketio, '_background_thread'):
            socketio._background_thread = threading.Thread(
                target=background_updater,
                args=(socketio,),
                daemon=True
            )
            socketio._background_thread.start()

    @socketio.on('disconnect')
    def handle_disconnect():
        print('Client disconnected')

    @socketio.on('app_status')
    def handle_app_status(data):
        app_id = data.get('app_id')
        if app_id:
            status = get_app_status(app_id)
            emit('app_status', {'app_id': app_id, 'status': status})

    @socketio.on('get_all_status')
    def handle_get_all_status():
        from app.apps import get_all_apps
        apps = get_all_apps()
        statuses = {str(app.id): get_app_status(app.id) for app in apps}
        emit('all_status', statuses)