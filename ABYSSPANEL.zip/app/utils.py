import os
import re

def safe_path_join(base, *paths):
    """تأكد أن المسار الناتج يقع داخل base"""
    full = os.path.join(base, *paths)
    real_base = os.path.realpath(base)
    real_full = os.path.realpath(full)
    if not real_full.startswith(real_base):
        raise ValueError("Path traversal detected")
    return full

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)

def validate_cron_expression(expression):
    """التحقق من صحة تعبير cron"""
    parts = expression.split()
    if len(parts) != 5:
        return False
    # يمكن إضافة تحقق أكثر دقة
    return True

def format_bytes(bytes):
    """تحويل بايت إلى شكل مقروء"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024:
            return f"{bytes:.2f} {unit}"
        bytes /= 1024
    return f"{bytes:.2f} PB"

def get_file_icon(filename):
    """إرجاع أيقونة مناسبة لنوع الملف"""
    ext = os.path.splitext(filename)[1].lower()
    icons = {
        '.py': '🐍', '.js': '📜', '.html': '🌐', '.css': '🎨',
        '.json': '📋', '.md': '📝', '.txt': '📄', '.sh': '⚙️',
        '.jpg': '🖼️', '.png': '🖼️', '.gif': '🖼️', '.svg': '🖼️',
        '.mp4': '🎬', '.mp3': '🎵', '.zip': '📦', '.tar': '📦',
        '.gz': '📦', '.db': '🗄️'
    }
    return icons.get(ext, '📄')