import psutil
from flask import Blueprint, render_template, jsonify
from flask_login import login_required

bp = Blueprint('resources', __name__)

@bp.route('/')
@login_required
def index():
    return render_template('resources.html')

@bp.route('/data')
@login_required
def data():
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    # معلومات إضافية
    cpu_count = psutil.cpu_count()
    cpu_freq = psutil.cpu_freq()
    swap = psutil.swap_memory()
    
    return jsonify({
        'cpu': cpu_percent,
        'cpu_count': cpu_count,
        'cpu_freq': cpu_freq._asdict() if cpu_freq else None,
        'memory': {
            'total': memory.total,
            'used': memory.used,
            'free': memory.free,
            'percent': memory.percent
        },
        'swap': {
            'total': swap.total,
            'used': swap.used,
            'percent': swap.percent
        },
        'disk': {
            'total': disk.total,
            'used': disk.used,
            'free': disk.free,
            'percent': disk.percent
        }
    })