import os
import shutil
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, send_file
from flask_login import login_required
from app.models import App
from app.utils import safe_path_join

bp = Blueprint('files', __name__)

def list_files(path):
    if not os.path.exists(path):
        return []
    items = []
    for name in os.listdir(path):
        full = os.path.join(path, name)
        items.append({
            'name': name,
            'is_dir': os.path.isdir(full),
            'size': os.path.getsize(full) if os.path.isfile(full) else 0,
            'modified': os.path.getmtime(full),
            'path': full
        })
    items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
    return items

def get_file_content(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except:
        return "⚠️ لا يمكن قراءة الملف (قد يكون ثنائي)"

def save_file(file_path, content):
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

def delete_path(path):
    if os.path.isdir(path):
        shutil.rmtree(path)
    else:
        os.remove(path)

def rename_path(old, new):
    os.rename(old, new)

@bp.route('/<int:app_id>')
@login_required
def index(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    path = request.args.get('path', '')
    full_path = safe_path_join(app.workdir, path) if path else app.workdir
    files = list_files(full_path)
    return render_template('files.html', app=app, files=files, current_path=path)

@bp.route('/<int:app_id>/view')
@login_required
def view_file(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    file_path = request.args.get('path')
    if not file_path:
        flash('لا يوجد مسار', 'danger')
        return redirect(url_for('files.index', app_id=app_id))
    full_path = safe_path_join(app.workdir, file_path)
    if not os.path.exists(full_path) or not os.path.isfile(full_path):
        flash('الملف غير موجود', 'danger')
        return redirect(url_for('files.index', app_id=app_id))
    content = get_file_content(full_path)
    return render_template('file_edit.html', app=app, file_path=file_path, content=content)

@bp.route('/<int:app_id>/download')
@login_required
def download_file(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    file_path = request.args.get('path')
    if not file_path:
        flash('لا يوجد مسار', 'danger')
        return redirect(url_for('files.index', app_id=app_id))
    full_path = safe_path_join(app.workdir, file_path)
    if not os.path.exists(full_path) or not os.path.isfile(full_path):
        flash('الملف غير موجود', 'danger')
        return redirect(url_for('files.index', app_id=app_id))
    return send_file(full_path, as_attachment=True, download_name=os.path.basename(file_path))

@bp.route('/<int:app_id>/save', methods=['POST'])
@login_required
def save_file_route(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    file_path = request.form.get('path')
    content = request.form.get('content')
    if not file_path:
        flash('لا يوجد مسار', 'danger')
        return redirect(url_for('files.index', app_id=app_id))
    full_path = safe_path_join(app.workdir, file_path)
    save_file(full_path, content)
    flash('تم حفظ الملف', 'success')
    return redirect(url_for('files.index', app_id=app_id, path=os.path.dirname(file_path)))

@bp.route('/<int:app_id>/upload', methods=['POST'])
@login_required
def upload(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    file = request.files.get('file')
    path = request.form.get('path', '')
    if file and file.filename:
        dest_dir = safe_path_join(app.workdir, path)
        os.makedirs(dest_dir, exist_ok=True)
        dest_path = os.path.join(dest_dir, file.filename)
        file.save(dest_path)
        flash('تم رفع الملف', 'success')
    return redirect(url_for('files.index', app_id=app_id, path=path))

@bp.route('/<int:app_id>/delete', methods=['POST'])
@login_required
def delete(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    file_path = request.form.get('path')
    if file_path:
        full_path = safe_path_join(app.workdir, file_path)
        delete_path(full_path)
        flash('تم الحذف', 'success')
    return redirect(url_for('files.index', app_id=app_id, path=os.path.dirname(file_path)))

@bp.route('/<int:app_id>/rename', methods=['POST'])
@login_required
def rename(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    old = request.form.get('old')
    new = request.form.get('new')
    if old and new:
        old_full = safe_path_join(app.workdir, old)
        new_full = safe_path_join(app.workdir, new)
        rename_path(old_full, new_full)
        flash('تم إعادة التسمية', 'success')
    return redirect(url_for('files.index', app_id=app_id, path=os.path.dirname(old)))

@bp.route('/<int:app_id>/mkdir', methods=['POST'])
@login_required
def mkdir(app_id):
    app = App.query.get(app_id)
    if not app:
        flash('تطبيق غير موجود', 'danger')
        return redirect(url_for('apps.list_apps'))
    dirname = request.form.get('dirname')
    path = request.form.get('path', '')
    if dirname:
        full_path = safe_path_join(app.workdir, path, dirname)
        os.makedirs(full_path, exist_ok=True)
        flash('تم إنشاء المجلد', 'success')
    return redirect(url_for('files.index', app_id=app_id, path=path))