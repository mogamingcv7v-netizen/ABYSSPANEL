from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, SelectField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length

class LoginForm(FlaskForm):
    username = StringField('اسم المستخدم', validators=[DataRequired()])
    password = PasswordField('كلمة المرور', validators=[DataRequired()])
    remember_me = BooleanField('تذكرني')
    submit = SubmitField('دخول')

class RegistrationForm(FlaskForm):
    username = StringField('اسم المستخدم', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('البريد الإلكتروني', validators=[DataRequired(), Email()])
    password = PasswordField('كلمة المرور', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('تأكيد كلمة المرور', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('تسجيل')

class AppForm(FlaskForm):
    name = StringField('اسم التطبيق', validators=[DataRequired()])
    type = SelectField('النوع', choices=[
        ('nodejs', 'Node.js'),
        ('python', 'Python'),
        ('bash', 'Bash Script'),
        ('php', 'PHP'),
        ('other', 'أخرى')
    ])
    command = TextAreaField('أمر التشغيل', validators=[DataRequired()])
    workdir = StringField('مسار العمل (اتركه فارغًا للاستخدام الافتراضي)')
    env_vars = TextAreaField('متغيرات البيئة (JSON)')
    submit = SubmitField('حفظ')

class CronForm(FlaskForm):
    name = StringField('اسم المهمة', validators=[DataRequired()])
    schedule = StringField('جدول التشغيل (مثال: * * * * *)', validators=[DataRequired()])
    command = TextAreaField('الأمر', validators=[DataRequired()])
    enabled = BooleanField('مفعلة')
    submit = SubmitField('حفظ')

class BackupForm(FlaskForm):
    name = StringField('اسم النسخة', validators=[DataRequired()])
    app_id = SelectField('التطبيق', choices=[], coerce=int)
    submit = SubmitField('إنشاء نسخة')