from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_socketio import SocketIO
from config import Config

db = SQLAlchemy()
login_manager = LoginManager()
socketio = SocketIO()

def create_app(config_class=Config):
    app = Flask(__name__, template_folder='../templates', static_folder='../static')
    app.config.from_object(config_class)

    db.init_app(app)
    login_manager.init_app(app)
    socketio.init_app(app, cors_allowed_origins="*")

    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'يرجى تسجيل الدخول أولاً'

    # تسجيل البلوبريتس
    from app.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')

    from app.apps import bp as apps_bp
    app.register_blueprint(apps_bp, url_prefix='/apps')

    from app.files import bp as files_bp
    app.register_blueprint(files_bp, url_prefix='/files')

    from app.processes import bp as processes_bp
    app.register_blueprint(processes_bp, url_prefix='/processes')

    from app.cron import bp as cron_bp
    app.register_blueprint(cron_bp, url_prefix='/cron')

    from app.backups import bp as backups_bp
    app.register_blueprint(backups_bp, url_prefix='/backups')

    from app.resources import bp as resources_bp
    app.register_blueprint(resources_bp, url_prefix='/resources')

    from app.themes import bp as themes_bp
    app.register_blueprint(themes_bp, url_prefix='/themes')

    from app.api import bp as api_bp
    app.register_blueprint(api_bp, url_prefix='/api/v1')

    from app.socket_events import register_socket_events
    register_socket_events(socketio)

    # فلتر dirname للقوالب
    @app.template_filter('dirname')
    def dirname_filter(path):
        import os
        return os.path.dirname(path)

    # الصفحة الرئيسية
    @app.route('/')
    def index():
        from flask import render_template
        from app.themes import get_current_theme
        from app.apps import get_all_apps
        from app.processes import get_app_status
        apps = get_all_apps()
        for app_item in apps:
            app_item.status = get_app_status(app_item.id)
        return render_template('index.html', apps=apps, theme=get_current_theme())

    return app