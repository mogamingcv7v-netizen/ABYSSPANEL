import subprocess
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required
from app import db
from app.models import CronJob
from app.forms import CronForm
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

bp = Blueprint('cron', __name__)
scheduler = BackgroundScheduler()
scheduler.start()

def run_cron_job(job_id):
    from app import create_app
    app = create_app()
    with app.app_context():
        job = CronJob.query.get(job_id)
        if job and job.enabled:
            try:
                subprocess.Popen(job.command, shell=True, start_new_session=True)
                job.last_run = datetime.utcnow()
                db.session.commit()
            except Exception as e:
                print(f"Cron job error: {e}")

def schedule_job(job):
    if job.enabled:
        trigger = CronTrigger.from_crontab(job.schedule)
        scheduler.add_job(
            func=run_cron_job,
            trigger=trigger,
            id=f'cron_{job.id}',
            args=[job.id],
            replace_existing=True
        )
        next_run = scheduler.get_job(f'cron_{job.id}').next_run_time
        if next_run:
            job.next_run = next_run
            db.session.commit()
    else:
        scheduler.remove_job(f'cron_{job.id}', silent=True)

@bp.route('/')
@login_required
def list_cron():
    jobs = CronJob.query.order_by(CronJob.created_at.desc()).all()
    return render_template('cron.html', jobs=jobs)

@bp.route('/new', methods=['GET', 'POST'])
@login_required
def new_cron():
    form = CronForm()
    if form.validate_on_submit():
        job = CronJob(
            name=form.name.data,
            schedule=form.schedule.data,
            command=form.command.data,
            enabled=form.enabled.data
        )
        db.session.add(job)
        db.session.commit()
        schedule_job(job)
        flash('تم إضافة المهمة', 'success')
        return redirect(url_for('cron.list_cron'))
    return render_template('cron_edit.html', form=form, job=None)

@bp.route('/<int:job_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_cron(job_id):
    job = CronJob.query.get(job_id)
    if not job:
        flash('المهمة غير موجودة', 'danger')
        return redirect(url_for('cron.list_cron'))
    form = CronForm(obj=job)
    if form.validate_on_submit():
        job.name = form.name.data
        job.schedule = form.schedule.data
        job.command = form.command.data
        job.enabled = form.enabled.data
        db.session.commit()
        schedule_job(job)
        flash('تم تحديث المهمة', 'success')
        return redirect(url_for('cron.list_cron'))
    return render_template('cron_edit.html', form=form, job=job)

@bp.route('/<int:job_id>/toggle', methods=['POST'])
@login_required
def toggle_cron(job_id):
    job = CronJob.query.get(job_id)
    if job:
        job.enabled = not job.enabled
        db.session.commit()
        schedule_job(job)
        flash(f'تم {"تفعيل" if job.enabled else "تعطيل"} المهمة', 'success')
    return redirect(url_for('cron.list_cron'))

@bp.route('/<int:job_id>/delete', methods=['POST'])
@login_required
def delete_cron(job_id):
    job = CronJob.query.get(job_id)
    if job:
        scheduler.remove_job(f'cron_{job.id}', silent=True)
        db.session.delete(job)
        db.session.commit()
        flash('تم حذف المهمة', 'success')
    return redirect(url_for('cron.list_cron'))

@bp.route('/<int:job_id>/run', methods=['POST'])
@login_required
def run_cron_now(job_id):
    job = CronJob.query.get(job_id)
    if job:
        run_cron_job(job.id)
        flash('تم تشغيل المهمة', 'success')
    return redirect(url_for('cron.list_cron'))